import React from "https://esm.sh/react";
import ReactDOM from "https://esm.sh/react-dom/client";

function MochaMochiLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-amber-50 to-mint-100 text-stone-800">
      <header className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-white/60 bg-white/50">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-white shadow-sm grid place-items-center text-xl">🍡</div>
            <span className="font-bold text-xl tracking-wide">MochaMochi</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#shop" className="hover:opacity-80">Shop</a>
            <a href="#about" className="hover:opacity-80">About</a>
            <a href="#faq" className="hover:opacity-80">FAQ</a>
            <a href="#contact" className="hover:opacity-80">Contact</a>
          </nav>
          <a href="#shop" className="rounded-2xl px-4 py-2 bg-stone-900 text-white shadow hover:opacity-90">Shop now</a>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-6xl px-4 py-14 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">Welcome to MochaMochi</h1>
            <p className="mt-3 text-lg md:text-xl">Cute & Cozy Designs — carry sweetness with you.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#shop" className="rounded-2xl px-5 py-3 bg-stone-900 text-white shadow hover:opacity-90">Shop Tote Bags</a>
              <a href="#collections" className="rounded-2xl px-5 py-3 bg-white shadow hover:opacity-90">Shop All</a>
            </div>
            <ul className="mt-6 grid grid-cols-2 gap-3 text-sm">
              <li className="flex items-center gap-2"><span>🌱</span> Eco-friendly printing</li>
              <li className="flex items-center gap-2"><span>🚚</span> Fast, tracked shipping</li>
              <li className="flex items-center gap-2"><span>✨</span> Kawaii pastel aesthetic</li>
              <li className="flex items-center gap-2"><span>💌</span> Gift message included</li>
            </ul>
          </div>
          <div className="rounded-3xl bg-white/70 p-6 shadow-lg">
            <div className="aspect-[3/2] w-full rounded-2xl grid place-items-center text-stone-500 border border-stone-200">
              <span className="p-6 text-center">Place your 1200×400 banner or product mockup here</span>
            </div>
          </div>
        </div>
      </section>

      <section id="shop" className="py-14">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-2xl md:text-3xl font-bold">Featured Picks</h2>
          <p className="text-stone-600 mt-1">Handpicked cuties from our latest drops.</p>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Kawaii Tote – Bear & Bunny", price: "$24", tag: "New" },
              { title: "Pastel Mug – Sweet Hearts", price: "$16", tag: "Bestseller" },
              { title: "Cozy Hoodie – MochaMochi", price: "$45", tag: "Limited" },
            ].map((p, i) => (
              <a key={i} href="#" className="group block rounded-3xl bg-white/70 p-4 shadow hover:shadow-md transition">
                <div className="aspect-square rounded-2xl bg-gradient-to-br from-rose-50 to-emerald-50 grid place-items-center text-stone-400 border border-stone-200">
                  <span>Product image</span>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold group-hover:underline underline-offset-4">{p.title}</h3>
                    <p className="text-stone-600 text-sm">{p.price}</p>
                  </div>
                  <span className="text-xs rounded-full px-2 py-1 bg-stone-900 text-white">{p.tag}</span>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="py-14">
        <div className="mx-auto max-w-6xl px-4 grid md:grid-cols-2 gap-10 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-2xl md:text-3xl font-bold">Sweetness with purpose</h2>
            <p className="mt-3 leading-relaxed text-stone-700">MochaMochi steht für liebevolle, kawaii-inspirierte Designs mit sanften Pastellfarben. Wir nutzen hochwertige, möglichst umweltfreundliche Materialien und bieten personalisierbare Geschenkoptionen, damit jedes Paket ein Lächeln bringt.</p>
            <ul className="mt-4 space-y-2 text-sm">
              <li>• Nachhaltige Produktion, wo immer möglich</li>
              <li>• Print-on-Demand: weniger Abfall, mehr Auswahl</li>
              <li>• Community-getriebene Kollektionen</li>
            </ul>
          </div>
          <div className="order-1 md:order-2 rounded-3xl bg-white/70 p-6 shadow-lg">
            <div className="aspect-video rounded-2xl grid place-items-center text-stone-500 border border-stone-200">
              <span className="p-6 text-center">Place a lifestyle photo or brand illustration here</span>
            </div>
          </div>
        </div>
      </section>

      <section id="faq" className="py-14 bg-white/60">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-2xl md:text-3xl font-bold">FAQ</h2>
          <div className="mt-6 grid md:grid-cols-2 gap-6">
            {[
              { q: "Wie lange dauert der Versand?", a: "In der Regel 3–7 Werktage nach Produktion. Du erhältst Tracking-Infos per E‑Mail." },
              { q: "Welche Materialien nutzt ihr?", a: "Je nach Produkt Bio‑Baumwolle, recycelte Stoffe und wasserbasierte Tinten, wo möglich." },
              { q: "Bietet ihr Geschenkoptionen an?", a: "Ja! Mit unserer süßen Gift Message und optionaler Personalisierung." },
              { q: "Wie fällt die Kleidung aus?", a: "True to size. Für Oversize‑Look eine Größe größer wählen." },
            ].map((f, i) => (
              <div key={i} className="rounded-2xl p-5 bg-white shadow-sm">
                <h3 className="font-semibold">{f.q}</h3>
                <p className="mt-1 text-stone-700 text-sm">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-14">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold">Join the Mochi Club</h2>
          <p className="mt-2 text-stone-700">Erhalte süße News, Drops & Geheimrabatte. Kein Spam, nur Mochi‑Liebe.</p>
          <div className="mt-6 mx-auto max-w-xl rounded-2xl bg-white/70 p-3 shadow">
            <form className="flex gap-2">
              <input className="flex-1 rounded-xl border border-stone-300 px-4 py-3 focus:outline-none" placeholder="Deine E‑Mail"/>
              <button className="rounded-xl px-5 py-3 bg-stone-900 text-white hover:opacity-90" type="button">Subscribe</button>
            </form>
          </div>
        </div>
      </section>

      <footer className="py-10 border-t border-stone-200/70">
        <div className="mx-auto max-w-6xl px-4 grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="font-semibold">MochaMochi</div>
            <p className="mt-2 text-stone-600">Cute & Cozy Designs • © {new Date().getFullYear()}</p>
          </div>
          <div className="space-y-1">
            <div className="font-semibold">Shop</div>
            <a href="#collections" className="block hover:underline">All Collections</a>
            <a href="#shop" className="block hover:underline">Tote Bags</a>
            <a href="#" className="block hover:underline">Mugs</a>
          </div>
          <div className="space-y-1">
            <div className="font-semibold">Help</div>
            <a href="#faq" className="block hover:underline">Shipping & Returns</a>
            <a href="#faq" className="block hover:underline">Sizing</a>
            <a href="#contact" className="block hover:underline">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<MochaMochiLanding />);
